enum Operator {
  ADD, SUBTRACT, MULTIPLY, DIVIDE
}

class Expression {
  double left_, right_;
  Operator op_;

  Expression(double left, double right, Operator op){
    this.left_  = left;
    this.right_ = right;
    this.op_    = op;
  }

  double evaluate() {
    switch (this.op_) {
      case ADD:
        return this.left_ + this.right_;
      case SUBTRACT:
        return this.left_ - this.right_;
      case MULTIPLY:
        return this.left_ * this.right_;
      case DIVIDE:
        return this.left_ / this.right_;
    }
  }
}

class Debug {

  public static void main(String[] args) {
    Operator[] ops = new Operator[5];
    ops[0] = ADD;
    ops[1] = SUBTRACT;
    ops[2] = MULTIPLY;
    ops[3] = DIVIDE;

    Expression[] exp = new Expression[ops.length];
    for (int i = 0; i < ops.length; ++i) {
      exp[i] = new Expression(2, 3, ops[i]);
    }

    for (int i = 0; i < ops.length; ++i) {
      System.out.println(exp[i].evaluate());
    }
  }
}

package de.uni_hannover.hci.task2;

import de.uni_hannover.hci.task2.model.*;

public class Main
{
    public static void main(String[] args) {
        Game game = new Game(10, 7, 1, 0, 6, 6, Direction.SOUTH);
        int[][] lab = {{1,0,1,1,1,1,1,1,1,1},
                       {1,0,0,0,1,0,0,0,0,1},
                       {1,0,1,1,1,0,1,1,0,1},
                       {1,0,0,1,0,0,1,0,0,1},
                       {1,1,0,0,0,1,1,1,0,1},
                       {1,0,0,1,0,1,0,0,0,1},
                       {1,1,1,1,1,1,0,1,1,1}};
        for (int i = 0; i < lab.length; i++) {
            for (int j = 0; j < lab[i].length; j++) {
                if (lab[i][j] == 1) {
                    game.toggleTree(j, i, true);
                }
            }
        }
        while (true) {
            if (game.atGoal()) {
                System.out.println(game.str());
                return;
            }
            game.turnRight();
            boolean canEnterRight = game.canEnter();
            game.turnLeft();
            if (canEnterRight) {
                game.turnRight();
                game.forward();
                System.out.println(game.str());
            } else {
                while (!game.canEnter()) {
                    game.turnLeft();
                }
                game.forward();
                System.out.println(game.str());
            }
        }
    }
}

package de.uni_hannover.hci.task2.model;

/**
 * Represents a Ladybug.
 * 
 * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
 * @version 04.05.2021
 */
public class Ladybug {
    /** Array of clovers. */
    private Clover[] clovers_;
    //0=north,1=east,2=south,3=west
    /** Looking direction */
    public Direction direction_;

    /** Standard constructor with variable direction.
     *
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
     * @param direction Initial viewing direction of Ladybug.
     */
    public Ladybug(Direction direction) {
        this.clovers_ = new Clover[10];
        this.direction_ = direction;
    }

    /** Standard constructor.
     *
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt; 
     */
    public Ladybug() {
        this(Direction.NORTH);
    }

    /**
     * Getter for direction.
     * 
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
     * @return Looking direction of Ladybug.
     */
    public Direction getDirection() {
        return this.direction_;
    }

    //either a setDirection or a turn{left,right} function as replacement is
    //needed

    /**
     * Turn the Player object to the right vorlaufen.
     * 
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
     */
    public void turnRight() {
        this.direction_ = this.direction_.right();

    }

    /**
     * Turn the ladybug right.
     * 
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
     */
    public void turnLeft() {
        this.direction_ = this.direction_.left();
    }

    //either a getter for clovers array or accumulated value should be here.

    /**
     * Get aggregate clover point values. 
     * 
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
     * @return aggregate clover points.
     */
    public int getCloverValues() {
        int result = 0;
        for (int i = 0; i < this.clovers_.length; ++i) {
            result += this.clovers_[i].getValue();
        }
        return result;
    }

    /** 
     * Signals whether the player can move forward.
     * 
     * @param tree Tile to check if it is walkable.
     * @return true if player can go forward.
     */
    public boolean canEnter(Tree tree) {
        return tree == null;
    }
    
    /** 
     * Returns string representation of the Ladybug.
     * 
     * Should be refactored to public String toString()
     * 
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
     * @return String representation of the playing field.
     */
    public String str() {
        switch (this.direction_) {
        case NORTH:
            return "N";
        case EAST:
            return "E";
        case SOUTH:
            return "S";
        case WEST:
            return "W";
        default:
            return "I"; //invalid
        }
    }
}

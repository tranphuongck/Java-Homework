package de.uni_hannover.hci.task2.model;

/**
 * Represents a Tree on the playing board.
 * 
 * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
 * @version 04.05.2021
 */
public class Tree {
    //Tree does not have any variables or special behavior yet,
    //so omitting constructor is fine.

    
    /** 
     * Returns string representation of the Tree.
     * 
     * Should be refactored to public String toString()
     * 
     * @author Patric Plattner &lt;patric.plattner@hci.uni-hannover.de&gt;
     * @return String representation of the playing field.
     */
    public String str() {
        return "X";
    }
}

package de.uni_hannover.hci.hoang_tran.task2;

public class Item {
	public String title;
	public String identifier;
	public double price;
	
	public Item (String title, String identifier) {
		this.title = title;
		this.identifier = identifier;
	}
}

package de.uni_hannover.hci.hoang_tran.task2.music;

public class CDAlbum extends MusicAlbum {

	public CDAlbum(String title, String identifier, String artist) {
		super(title, identifier, artist);
		super.price = 14.99;
	}

}

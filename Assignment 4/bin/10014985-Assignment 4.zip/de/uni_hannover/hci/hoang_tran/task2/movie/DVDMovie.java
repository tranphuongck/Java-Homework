package de.uni_hannover.hci.hoang_tran.task2.movie;

public class DVDMovie extends Movie {

	public DVDMovie(String title, String identifier) {
		super(title, identifier);
		super.price = 9.99;
	}

}

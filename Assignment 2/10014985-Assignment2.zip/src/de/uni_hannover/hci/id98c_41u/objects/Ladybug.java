//Player character object
package de.uni_hannover.hci.id98c_41u.objects;

public class Ladybug {
	String direction;
	int[] clover;
	
	public Ladybug (String direction, int[] clover) {
		this.direction = direction;
		this.clover = clover;
	}
	
	public void setDirection(String input) {
		switch (input) {
		case "W":
			direction = "N";
			break;
		case "D":
			direction = "E";
			break;
		case "S":
			direction = "S";
			break;
		case "A":
			direction = "W";
			break;
		}
	}
	
	public String getDirection() {
		return direction;
	}

	public int[] getClover() {
		return clover;
	}
	
	public void setClover(int[] clover) {
		this.clover = clover;
	}
	
	public void printLadybug(String direction) {
		switch (direction) {
		case "N":
			System.out.println("^");
			break;
		case "E":
			System.out.println(">");
			break;
		case "S":
			System.out.println("v");
			break;
		case "W":
			System.out.println("<");
			break;
		}
	}
	
}

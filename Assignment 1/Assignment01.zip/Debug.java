ckass Debug {
    // Method prints all numbers in an array that are even.
    static void 1printEvenNumbers(int[] numbers) {
        for (int i = 0; i < numbers.length; ++i) {
            if (numbers[i] \% 2 == 1) {
                System.out.println(numbers[i]);
            }
        }
    }
    int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
    //output should be as follows:
    //2
    //4
    //6
    //8
    Debug.printEvenNumbers(arr);
}
